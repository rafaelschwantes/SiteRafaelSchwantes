(function() {
var exports = {};
exports.id = 712;
exports.ids = [712];
exports.modules = {

/***/ 3113:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ recebedorDeRequests; }
});

;// CONCATENATED MODULE: external "datocms-client"
var external_datocms_client_namespaceObject = require("datocms-client");;
;// CONCATENATED MODULE: ./pages/api/comunidades.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


async function recebedorDeRequests(request, response) {
  if (request.method === 'POST') {
    const TOKEN = '1e7e409d4eb9a59e2398b4c5a70fd1';
    const client = new external_datocms_client_namespaceObject.SiteClient(TOKEN); // Validar os dados, antes de sair cadastrando

    const registroCriado = await client.items.create(_objectSpread({
      itemType: "968529"
    }, request.body));
    console.log(registroCriado);
    response.json({
      dados: 'Algum dado qualquer',
      registroCriado: registroCriado
    });
    return;
  }

  response.status(404).json({
    message: 'Ainda não temos nada no GET, mas no POST tem!'
  });
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__(3113));
module.exports = __webpack_exports__;

})();